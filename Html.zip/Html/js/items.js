var items = [
    {
        id: 1,
        child: [
            {name: '一房'},
            {name: '二房'},
            {name: '三房'},
            {name: '四房'},
            {name: '五房及以上'}
        ]
    },
    {
        id: 0,
        child: [
            {name: '50万-80万'},
            {name: '80万-120万'},
            {name: '120万-200万'},
            {name: '200万-400万'},
            {name: '500万以上'}
        ]
    },
    {
        id: 3,
        child: [
            {name: '精装房'},
            {name: '普通装修'},
            {name: '毛坯房'}
        ]
    },
    {
        id: 2,
        child: [
            {name: '一室一厅'},
            {name: '两室一厅'},
            {name: '三室两厅'},
            {name: '四室两厅'},
            {name: '独栋别墅'}
        ]
    }
]